# Alpha3

`alpha3` is a Python package that provides a simple command line interface to convert country names to their corresponding alpha3 codes using the OpenSoft API.

## Installation

```bash
pip install alpha3
```

## Usage

```bash
alpha3 'United States'
```
